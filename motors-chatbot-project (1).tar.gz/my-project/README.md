# MOTORS Chatbot - AI Powered Assistant

مساعد ذكاء اصطناعي متخصص لموقع MOTORS لبيع وشراء السيارات.

## 🚀 المميزات

- ✅ **بوت ذكاء اصطناعي مدرب على الموقع:** يجيب على جميع الأسئلة المتعلقة بموقع MOTORS والسيارات
- ✅ **بحث ذكي عن الإعلانات:** يبحث عن إعلانات حقيقية ويرسل روابطها
- ✅ **دعم كامل للموقع:** شرح جميع الأقسام والمميزات (السيارات، البيع، المزادات)
- ✅ **واجهة دردشة عصرية:** تصميم نظيف مثل ChatGPT بدون إطارات
- ✅ **رسائل مخصصة:** لون أحمر للأخطاء، إجابات منظمة
- ✅ **لوجو شفاف:** بدون خلفية بيضاء
- ✅ **استجابة سريعة:** تكامل مع API حقيقي لردود ذكية
- ✅ **دعم متعدد الدول:** معلومات عن جميع الدول المتاحة
- ✅ **روابط مباشرة:** روابط حقيقية للأقسام والإعلانات

## 📋 المتطلبات

- Node.js 18 أو أحدث
- Bun (مستحسن للأداء)
- مفتاح API من ZAI (مضمن في الكود)

## 🔧 التثبيت

### 1. استنساخ الكود
```bash
# استخدام Git
git clone <repository-url>
cd my-project

# أو تحميل الملف المضغوط
# (سيتم توفير الملف my-project.tar.gz)
```

### 2. تثبيت الحزم
```bash
# استخدام Bun (مستحسن)
bun install

# أو npm
npm install
```

### 3. إعداد متغيرات البيئة
```bash
# مفتاح API مضمن بالفعل في:
# src/app/api/chatbot/route.ts
```

## 🎯 كيفية الاستخدام

### تشغيل المشروع محلياً

```bash
# استخدام Bun
bun run dev

# أو npm
npm run dev
```

التطبيق سيعمل على: http://localhost:3000

### استخدام الدردشة

1. اضغط على زر "تحدث مع مساعد MOTORS 🤖" أسفل الصفحة
2. اكتب سؤالك أو استخدم أحد الاقتراحات السريعة
3. انتظر الرد من المساعد الذكي

### أمثلة الأسئلة

```
كيف أشتري سيارة؟
كيف أبيع سيارتي؟
أريد Toyota Camry 2022
نصائح لشراء سيارة مستعملة
ماهي المزادات المتاحة؟
```

## 📁 هيكل المشروع

```
my-project/
├── public/                          # الملفات الثابتة
│   ├── motors-logo-transparent.png  # اللوجو الشفاف
│   └── motors-logo-new.png        # اللوجو القديم
├── src/
│   ├── app/
│   │   ├── page.tsx              # الصفحة الرئيسية
│   │   ├── layout.tsx            # Layout للتطبيق
│   │   └── api/
│   │       └── chatbot/
│   │           └── route.ts   # API endpoint للدردشة
│   └── lib/                      # المكتبات المشتركة
├── package.json
├── tsconfig.json
├── tailwind.config.ts
└── next.config.js
```

## 🎨 التقنيات المستخدمة

- **Frontend:** Next.js 15, React 18, TypeScript
- **Styling:** Tailwind CSS 4
- **Icons:** Lucide React
- **Backend:** Next.js API Routes
- **AI SDK:** z-ai-web-dev-sdk
- **Runtime:** Bun / Node.js

## 🔧 التخصيص

### تغيير الألوان
```typescript
// src/app/page.tsx
const colors = {
  primary: '#0a1628', // أزرق داكن
  accent: '#e63946',  // أحمر
  text: '#1e293b'     // رمادي
}
```

### تحديث الـ System Prompt
```typescript
// src/app/api/chatbot/route.ts
const SYSTEM_PROMPT = `
أنت مساعد MOTORS الذكي...
[قم بتعديل محتوى البوت حسب حاجتك]
`;
```

## 📝 الإرشادات

### للإضافة إلى GitHub

1. **إنشاء مستودع جديد على GitHub:**
   - اذهب إلى https://github.com/new
   - اختر اسم المستودع (مثل: motors-chatbot)
   - اجعله Public أو Private
   - انقر على "Create repository"

2. **رفع الكود:**
   ```bash
   # إضافة مستودع GitHub
   cd my-project
   git remote add origin https://github.com/YOUR_USERNAME/REPO_NAME.git

   # رفع الكود
   git push -u origin master
   ```

3. **أو رفع الملفات يدوياً:**
   - اذهب إلى المستودع على GitHub
   - اضغط على "Upload files"
   - اسحب وأفلت ملف `my-project.tar.gz`
   - انقر على "Commit changes"

### للنشر على Vercel (مستحسن)

1. **تثبيت Vercel CLI:**
   ```bash
   npm i -g vercel
   ```

2. **نشر المشروع:**
   ```bash
   vercel
   ```

3. **اتبع التعليمات:**
   - اختر "Yes" لجميع الأسئلة
   - سيتم نشر المشروع على Vercel تلقائياً

### للنشر على Netlify

1. **بناء المشروع:**
   ```bash
   bun run build
   ```

2. **نشر على Netlify:**
   ```bash
   netlify deploy --prod --dir=out
   ```

## 🐛 حل المشاكل

### الخطأ: "API key is missing"
```bash
# تحقق من أن مفتاح API موجود في:
# src/app/api/chatbot/route.ts
```

### الخطأ: "Cannot find module"
```bash
# تثبيت الحزم مرة أخرى
bun install
```

### الخطأ: "Module not found: lucide-react"
```bash
# تثبيت الحزمة
bun install lucide-react
```

## 📞 الدعم

إذا واجهت أي مشاكل أو كانت لديك أسئلة:
- راجع ملف `worklog.md` للتفاصيل الكاملة
- تحقق من سجلات التطوير في `dev.log`
- تأكد من أن جميع الملفات مرفوعة بشكل صحيح

## 📄 الترخيص

هذا المشروع مفتوح المصدر ومتاح بموجب ترخيص MIT.

---

**تم التطوير بواسطة:**
- Next.js Framework
- ZAI SDK
- React & TypeScript
- Tailwind CSS

**© 2024 MOTORS Sooq** - جميع الحقوق محفوظة.
