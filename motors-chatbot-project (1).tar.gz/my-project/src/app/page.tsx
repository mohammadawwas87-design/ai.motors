'use client'

import { useState } from 'react'
import { MessageSquare, X, Send, Car, ShoppingCart, HelpCircle, TrendingUp, Shield } from 'lucide-react'
import React from 'react'

// Function to format bot messages - NO BORDERS, organized like ChatGPT
const formatMessage = (content: string) => {
  // Split content into paragraphs
  const paragraphs = content.split('\n').filter(p => p.trim())

  // Format each paragraph - NO BORDERS, just text like ChatGPT
  return paragraphs.map((paragraph, index) => {
    // Clean emoji formatting
    let formattedParagraph = paragraph
      .replace(/\*\*(.*?)\*\*/g, '<span class="font-semibold">$1</span>') // Bold only
      .replace(/\*\*(.*?)\*/g, '<span class="font-semibold">$1</span>') // Bold
      .replace(/🎯/g, '<span class="mr-1">🎯</span>')
      .replace(/📋/g, '<span class="mr-1">📋</span>')
      .replace(/🏢/g, '<span class="mr-1">🏢</span>')
      .replace(/🎨/g, '<span class="mr-1">🎨</span>')
      .replace(/🌍/g, '<span class="mr-1">🌍</span>')
      .replace(/🧠/g, '<span class="mr-1">🧠</span>')
      .replace(/⚠️/g, '<span class="mr-1 text-yellow-600">⚠️</span>')
      .replace(/✅/g, '<span class="mr-1 text-green-600">✅</span>')
      .replace(/💡/g, '<span class="mr-1 text-blue-600">💡</span>')
      .replace(/🎯/g, '<span class="mr-1">🎯</span>')
      .replace(/🏆/g, '<span class="mr-1">🏆</span>')
      .replace(/🎨/g, '<span class="mr-1">🎨</span>')
      .replace(/📝/g, '<span class="mr-1">📝</span>')
      .replace(/💬/g, '<span class="mr-1">💬</span>')
      .replace(/🔍/g, '<span class="mr-1">🔍</span>')
      .replace(/📍/g, '<span class="mr-1">📍</span>')
      .replace(/⏰/g, '<span class="mr-1">⏰</span>')
      .replace(/💰/g, '<span class="mr-1">💰</span>')
      .replace(/🛠️/g, '<span class="mr-1">🛠️</span>')

    // Simple formatting for lists - like ChatGPT
    formattedParagraph = formattedParagraph
      .replace(/^(\d+)\.\s+/gm, '<span class="font-medium text-slate-700 mr-1">$1.</span>')
      .replace(/^[-•]\s+/gm, '<span class="font-medium text-slate-700 mr-1">•</span>')

    // NO BACKGROUND, NO BORDER - just clean text like ChatGPT
    return `<div key=${index} class="mb-2">
      <p class="text-sm leading-relaxed whitespace-pre-wrap text-slate-700">${formattedParagraph}</p>
    </div>`
  }).join('')
}

export default function Home() {
  const [isChatOpen, setIsChatOpen] = useState(false)
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant', content: string }>>([
    {
      role: 'assistant',
      content: 'مرحباً! 👋 أنا مساعد MOTORS الذكي، هنا لمساعدتك في كل ما يخص السيارات. كيف يمكنني مساعدتك اليوم؟'
    }
  ])
  const [inputMessage, setInputMessage] = useState('')
  const [isLoading, setIsLoading] = useState(false)

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return

    const userMessage = inputMessage.trim()
    setMessages(prev => [...prev, { role: 'user', content: userMessage }])
    setInputMessage('')
    setIsLoading(true)

    try {
      const response = await fetch('/api/chatbot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userMessage, history: messages })
      })

      const data = await response.json()

      if (data.success) {
        setMessages(prev => [...prev, { role: 'assistant', content: data.reply }])

        // Add helpful closing message after 3 exchanges if user seems satisfied
        const messageCount = messages.length
        const lastAssistantMessage = messages.filter(m => m.role === 'assistant').pop()
        const userSatisfactionKeywords = ['شكراً', 'ممتاز', 'رائع', 'واضح', 'مفيد', 'شكرًا', 'شكر', 'حلو', 'كفو', 'مفيدة']

        if (messageCount >= 6 && userSatisfactionKeywords.some(keyword => userMessage.toLowerCase().includes(keyword))) {
          setTimeout(() => {
            setMessages(prev => [...prev, {
              role: 'assistant',
              content: 'أتمنى لك تجربة آمنة وسلسة مع موتورزسوق! إذا احتجت أي مساعدة أخرى في المستقبل، أنا هنا دائماً. 🚗✨'
            }])
          }, 1500)
        }
      } else {
        setMessages(prev => [...prev, { role: 'assistant', content: 'عذراً، حدث خطأ. يرجى المحاولة مرة أخرى.' }])
      }
    } catch (error) {
      setMessages(prev => [...prev, { role: 'assistant', content: 'عذراً، حدث خطأ في الاتصال. يرجى المحاولة مرة أخرى.' }])
    } finally {
      setIsLoading(false)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const quickSuggestions = [
    { text: 'كيف أشتري سيارة؟', icon: <Car className="w-4 h-4" /> },
    { text: 'كيف أبيع سيارتي؟', icon: <ShoppingCart className="w-4 h-4" /> },
    { text: 'قارن بين سيارتين', icon: <TrendingUp className="w-4 h-4" /> },
    { text: 'نصائح الشراء', icon: <Shield className="w-4 h-4" /> },
    { text: 'البحث عن سيارات', icon: <Car className="w-4 h-4" /> },
    { text: 'إضافة إعلان', icon: <ShoppingCart className="w-4 h-4" /> },
    { text: 'المزادات المتاحة', icon: <TrendingUp className="w-4 h-4" /> },
  ]

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-[#0a1628] text-white shadow-md border-b border-[#e63946]/20">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="inline-block bg-transparent">
            <img
                src="/motors-logo-transparent.png"
                alt="MOTORS Logo"
                className="h-16 w-auto inline-block"
              />
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <a href="https://motorssooq.com/en" target="_blank" className="hover:text-[#e63946] transition-colors font-medium">الرئيسية</a>
            <a href="https://motorssooq.com/en/all-ads" target="_blank" className="hover:text-[#e63946] transition-colors font-medium">السيارات</a>
            <a href="https://motorssooq.com/en/add-ad" target="_blank" className="hover:text-[#e63946] transition-colors font-medium">بيع سيارتك</a>
            <a href="https://motorssooq.com/en/auctions" target="_blank" className="hover:text-[#e63946] transition-colors font-medium">المزادات</a>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <main className="min-h-[calc(100vh-80px)]">
        {/* Logo Display - NO WHITE BACKGROUND */}
        <div className="text-center mb-12 py-8">
          <div className="inline-block bg-transparent">
            <img
              src="/motors-logo-transparent.png"
              alt="MOTORS Logo"
              className="h-32 md:h-40 w-auto inline-block"
            />
          </div>
        </div>


        {/* Features Grid */}
        <div className="container mx-auto px-4 mb-12">
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white border border-slate-200 rounded-lg p-6 hover:shadow-lg hover:border-[#e63946] transition-all">
              <div className="bg-[#e63946]/10 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                <Car className="w-6 h-6 text-[#e63946]" />
              </div>
              <h3 className="text-xl font-bold text-[#0a1628] mb-2">شراء سيارة</h3>
              <p className="text-slate-600">تصفح آلاف السيارات المعروضة بأفضل الأسعار ومواصفات مفصلة</p>
            </div>

            <div className="bg-white border border-slate-200 rounded-lg p-6 hover:shadow-lg hover:border-[#e63946] transition-all">
              <div className="bg-[#e63946]/10 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                <ShoppingCart className="w-6 h-6 text-[#e63946]" />
              </div>
              <h3 className="text-xl font-bold text-[#0a1628] mb-2">بيع سيارة</h3>
              <p className="text-slate-600">أنشئ إعلانك في دقائق وابدأ في استقبال العروض فوراً</p>
            </div>

            <div className="bg-white border border-slate-200 rounded-lg p-6 hover:shadow-lg hover:border-[#e63946] transition-all">
              <div className="bg-[#e63946]/10 rounded-full w-12 h-12 flex items-center justify-center mb-4">
                <TrendingUp className="w-6 h-6 text-[#e63946]" />
              </div>
              <h3 className="text-xl font-bold text-[#0a1628] mb-2">مقارنة الأسعار</h3>
              <p className="text-slate-600">قارن بين السيارات وخذ قرار شراء مدروس</p>
            </div>
          </div>
        </div>

        {/* Info Cards */}
        <div className="container mx-auto px-4 pb-12">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-gradient-to-br from-[#0a1628] to-[#1a2942] rounded-lg p-6 text-white shadow-lg">
              <h3 className="text-2xl font-bold mb-4">💡 نصائح سريعة</h3>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <Shield className="w-5 h-5 text-[#e63946] mt-0.5 flex-shrink-0" />
                  <span>تحقق من تاريخ الصيانة قبل الشراء</span>
                </li>
                <li className="flex items-start gap-3">
                  <Shield className="w-5 h-5 text-[#e63946] mt-0.5 flex-shrink-0" />
                  <span>قارن الأسعار من مصادر متعددة</span>
                </li>
                <li className="flex items-start gap-3">
                  <Shield className="w-5 h-5 text-[#e63946] mt-0.5 flex-shrink-0" />
                  <span>اختبر السيارة على الطريق قبل الشراء</span>
                </li>
              </ul>
            </div>

            <div className="bg-white border border-slate-200 rounded-lg p-6 shadow-lg">
              <h3 className="text-2xl font-bold text-[#0a1628] mb-4">🎯 كيف نساعدك؟</h3>
              <ul className="space-y-3 text-slate-600">
                <li className="flex items-start gap-3">
                  <HelpCircle className="w-5 h-5 text-[#e63946] mt-0.5 flex-shrink-0" />
                  <span>إجابة على جميع استفساراتك حول السيارات</span>
                </li>
                <li className="flex items-start gap-3">
                  <HelpCircle className="w-5 h-5 text-[#e63946] mt-0.5 flex-shrink-0" />
                  <span>مساعدة في نشر إعلانات بيع سيارتك</span>
                </li>
                <li className="flex items-start gap-3">
                  <HelpCircle className="w-5 h-5 text-[#e63946] mt-0.5 flex-shrink-0" />
                  <span>نصائح وإرشادات عملية للشراء الآمن</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </main>

      {/* Footer - Matching MotorsSooq Style */}
      <footer className="bg-[#0a1628] text-white py-12">
        <div className="container mx-auto px-4">
          {/* Logo and Description */}
          <div className="text-center mb-8">
            <img
              src="/motors-logo-transparent.png"
              alt="MOTORS Logo"
              className="h-20 w-auto mx-auto"
            />
            <p className="text-slate-300 text-sm leading-relaxed">
              We aim to create a safe and reliable ad space that connects advertisers with their audience effectively.
            </p>
          </div>

          {/* Footer Columns */}
          <div className="grid md:grid-cols-5 gap-8 mb-8">
            {/* Countries */}
            <div>
              <h4 className="text-lg font-bold mb-4 text-[#e63946]">البلدان</h4>
              <ul className="space-y-2 text-sm">
                <li className="hover:text-[#e63946] cursor-pointer transition-colors">الأردن</li>
                <li className="hover:text-[#e63946] cursor-pointer transition-colors">الإمارات العربية المتحدة</li>
                <li className="hover:text-[#e63946] cursor-pointer transition-colors">الكويت</li>
                <li className="hover:text-[#e63946] cursor-pointer transition-colors">قطر</li>
                <li className="hover:text-[#e63946] cursor-pointer transition-colors">السعودية</li>
                <li className="hover:text-[#e63946] cursor-pointer transition-colors">عمان</li>
              </ul>
            </div>

            {/* Categories */}
            <div>
              <h4 className="text-lg font-bold mb-4 text-[#e63946]">التصنيفات</h4>
              <ul className="space-y-2 text-sm">
                <li className="hover:text-[#e63946] cursor-pointer transition-colors">سيارات</li>
                <li className="hover:text-[#e63946] cursor-pointer transition-colors">شاحنات</li>
                <li className="hover:text-[#e63946] cursor-pointer transition-colors">دراجات نارية</li>
                <li className="hover:text-[#e63946] cursor-pointer transition-colors">قطع غيار</li>
                <li className="hover:text-[#e63946] cursor-pointer transition-colors">معدات ثقيلة</li>
                <li className="hover:text-[#e63946] cursor-pointer transition-colors">أخرى...</li>
              </ul>
            </div>

            {/* About Us */}
            <div>
              <h4 className="text-lg font-bold mb-4 text-[#e63946]">عن الموقع</h4>
              <ul className="space-y-2 text-sm">
                <li className="hover:text-[#e63946] cursor-pointer transition-colors">قصتنا</li>
                <li className="hover:text-[#e63946] cursor-pointer transition-colors">شروط الاستخدام</li>
                <li className="hover:text-[#e63946] cursor-pointer transition-colors">سياسة الخصوصية</li>
              </ul>
            </div>

            {/* Contact Us */}
            <div>
              <h4 className="text-lg font-bold mb-4 text-[#e63946]">تواصل معنا</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <span className="text-slate-300">info@motorssooq.com</span>
                </li>
                <li className="hover:text-[#e63946] cursor-pointer transition-colors">
                  نموذج التواصل
                </li>
              </ul>
            </div>

            {/* Language */}
            <div>
              <h4 className="text-lg font-bold mb-4 text-[#e63946]">اللغة</h4>
              <ul className="space-y-2 text-sm">
                <li className="hover:text-[#e63946] cursor-pointer transition-colors flex items-center gap-2">
                  <span>العربية</span>
                  <span className="text-xs bg-[#e63946] px-2 py-0.5 rounded">محدد</span>
                </li>
                <li className="hover:text-[#e63946] cursor-pointer transition-colors">English</li>
              </ul>
            </div>
          </div>

          {/* Copyright */}
          <div className="border-t border-white/20 pt-6 text-center">
            <p className="text-slate-400 text-sm">
              © 2024 MOTORS Sooq. جميع الحقوق محفوظة.
            </p>
          </div>
        </div>
      </footer>

      {/* Chat Button - Matching MotorsSooq Style */}
      <button
        onClick={() => setIsChatOpen(true)}
        className={`fixed bottom-6 right-6 bg-[#e63946] hover:bg-[#c92a37] text-white font-bold px-6 py-3 rounded-full shadow-lg transition-all duration-300 z-50 ${
          isChatOpen ? 'scale-0 opacity-0' : 'scale-100 opacity-100'
        }`}
        style={{ boxShadow: '0 4px 14px rgba(230, 57, 70, 0.4)' }}
      >
        <div className="flex items-center gap-2">
          <MessageSquare className="w-5 h-5" />
          <span>تحدث مع مساعد MOTORS 🤖</span>
        </div>
      </button>

      {/* Chat Window - Matching MotorsSooq Design - Larger */}
      <div
        className={`fixed bottom-24 right-6 w-full max-w-[500px] bg-white rounded-xl shadow-2xl border border-slate-200 transition-all duration-300 z-50 ${
          isChatOpen ? 'scale-100 opacity-100' : 'scale-0 opacity-0'
        }`}
        style={{ boxShadow: '0 10px 40px rgba(10, 22, 40, 0.3)' }}
      >
        {/* Chat Header */}
        <div className="bg-[#0a1628] text-white px-5 py-4 rounded-t-xl flex items-center justify-between border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="bg-[#e63946] rounded-full w-9 h-9 flex items-center justify-center">
              <Car className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base">مساعد MOTORS</h3>
              <p className="text-xs text-green-400 flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"></span>
                متصل الآن
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsChatOpen(false)}
            className="hover:bg-white/10 rounded-full p-1.5 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Chat Messages - Larger, NO BORDERS */}
        <div className="h-96 overflow-y-auto p-4">
          {messages.map((message, index) => (
            <div
              key={index}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'} mb-3`}
            >
              <div
                className={`max-w-[85%] rounded-xl overflow-hidden ${
                  message.role === 'user'
                    ? 'bg-[#e63946] text-white px-4 py-2.5 shadow-md'
                    : ''
                }`}
              >
                {message.role === 'assistant' ? (
                  <div className="text-sm whitespace-pre-wrap">
                    <div dangerouslySetInnerHTML={{ __html: formatMessage(message.content) }} />
                  </div>
                ) : (
                  <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                )}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start mb-3">
              <div className="bg-slate-100 rounded-xl px-4 py-2.5">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-[#e63946] rounded-full animate-bounce" />
                  <div className="w-2 h-2 bg-[#e63946] rounded-full animate-bounce delay-100" />
                  <div className="w-2 h-2 bg-[#e63946] rounded-full animate-bounce delay-200" />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Quick Suggestions - More options */}
        {messages.length === 1 && !isLoading && (
          <div className="px-4 pb-3">
            <div className="flex flex-wrap gap-2">
              {quickSuggestions.map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => {
                    setInputMessage(suggestion.text)
                  }}
                  className="flex items-center gap-2 bg-white hover:bg-slate-50 text-slate-700 px-3 py-2 rounded-full text-sm font-medium border border-slate-200 hover:border-[#e63946] transition-all"
                >
                  {suggestion.icon}
                  {suggestion.text}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Chat Input - Matching MotorsSooq Style */}
        <div className="border-t border-slate-200 p-3">
          <div className="flex gap-2">
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="اكتب رسالتك هنا..."
              className="flex-1 bg-slate-100 rounded-full px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#e63946] focus:bg-white transition-all border border-slate-200"
              disabled={isLoading}
            />
            <button
              onClick={handleSendMessage}
              disabled={isLoading || !inputMessage.trim()}
              className="bg-[#e63946] hover:bg-[#c92a37] disabled:bg-slate-300 text-white rounded-full p-2.5 transition-all disabled:cursor-not-allowed"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
